/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

/* Freescale includes. */
#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"

#include "semphr.h"
#include <stdio.h> // for scanf
#include <ctype.h>

volatile char str[100]; // user input string

void userinput_sem(void* pvParameters)
{
	PRINTF("Enter task 1 - user input\n");
	SemaphoreHandle_t* semaphores = (SemaphoreHandle_t*)pvParameters;
	SemaphoreHandle_t print_semaphore = semaphores[0];
	SemaphoreHandle_t PRINTCAP_semaphore = semaphores[1];
	SemaphoreHandle_t userinput_semaphore = semaphores[2];
	BaseType_t status1, status2;
	volatile int flag = 0;
	PRINTF("Task 1 enter, Please enter the string:\n");
	while(1)
	{
		while(flag == 0){
			fgets((char*)str, sizeof(str), stdin); //will wait until hit "ENTER" on keyboard
			//scanf("%99s",str); //scanf do not handle "SPACE"
			PRINTF("User input complete, jump out the current semaphore\n");
			flag = 1;
		}
		//lock
		PRINTF("before lock\n");
		status1 = xSemaphoreTake(userinput_semaphore, portMAX_DELAY);
		status2 = xSemaphoreTake(userinput_semaphore, portMAX_DELAY);
		PRINTF("after lock\n");
		if (status1 != pdPASS || status2 != pdPASS)
		{
			PRINTF("Failed to acquire print_semaphore\r\n");
			while (1);
		}
		//unlock
		xSemaphoreGive(print_semaphore);
		xSemaphoreGive(PRINTCAP_semaphore);
		//xSemaphoreGive(PRINTCAP_semaphore);
		vTaskDelay(1000 / portTICK_PERIOD_MS);
	}
}

void print_sem(void* pvParameters)
{
	PRINTF("Enter print_sem\n");
	SemaphoreHandle_t* semaphores = (SemaphoreHandle_t*)pvParameters;
	SemaphoreHandle_t print_semaphore = semaphores[0];
	//SemaphoreHandle_t PRINTCAP_semaphore = semaphores[1];
	SemaphoreHandle_t userinput_semaphore = semaphores[2];
	BaseType_t status;
	while(1)
	{
		PRINTF("HEREH 1\n");
		//unlock
		xSemaphoreGive(userinput_semaphore);
		PRINTF("HEREH 2\n");
		//lock
		status = xSemaphoreTake(print_semaphore, portMAX_DELAY);
		if (status != pdPASS)
		{
			PRINTF("Failed to acquire userinput_semaphore\n");
			while (1);
		}
		PRINTF("User input = %s\n", str);
		vTaskDelay(1000 / portTICK_PERIOD_MS);

	}
	PRINTF("Leave consumer1_sem\n");
}

void PRINTCAP_sem(void* pvParameters)
	{
	PRINTF("Enter PRINTCAP_sem\n");
	SemaphoreHandle_t* semaphores = (SemaphoreHandle_t*)pvParameters;
	SemaphoreHandle_t PRINTCAP_semaphore = semaphores[1];
	SemaphoreHandle_t userinput_semaphore = semaphores[2];
	BaseType_t status;
	while(1)
	{
		PRINTF("HEREH 3\n");
		//unlock
		xSemaphoreGive(userinput_semaphore);
		PRINTF("HEREH 4\n");
		//lock
		status = xSemaphoreTake(PRINTCAP_semaphore, portMAX_DELAY);
		PRINTF("HEREH 5\n");
		if (status != pdPASS)
		{
			PRINTF("Failed to acquire producer2_semaphore\r\n");
			while (1);
		}
		PRINTF("HEREH 6\n");
		int userInputSize = sizeof(str)/sizeof(str[0]);
		char strCAP[userInputSize];
	    for (int i=0; i<userInputSize; i++) {
	        // If the character is a letter, convert it to uppercase
	        if (isalpha(str[i])) {
	            strCAP[i] = toupper(str[i]);
	        }
	    }

		PRINTF("User input (CAPTICAL) = %s\n", strCAP);
		vTaskDelay(1000 / portTICK_PERIOD_MS);
	}
	PRINTF("Leave consumer2_sem\n");
}


int main(void)
{
	BaseType_t status;
	/* Init board hardware. */
	BOARD_InitBootPins();
	BOARD_InitBootClocks();
	BOARD_InitDebugConsole();
	SemaphoreHandle_t* semaphores = (SemaphoreHandle_t*) malloc(3 * sizeof(
	SemaphoreHandle_t));
	semaphores[0] = xSemaphoreCreateBinary(); //Producer1_sem
	semaphores[1] = xSemaphoreCreateBinary(); //Producer2_sem
	semaphores[2] = xSemaphoreCreateBinary();//xSemaphoreCreateCounting(2, 2); //consumer_sem

	// task 1 - producer
	status = xTaskCreate(userinput_sem, "producer", 200, (void*)semaphores, 2, NULL);
	if (status != pdPASS)
	{
		PRINTF("Task creation failed!.\r\n");
		while (1);
	}
	// task 2 - consumer 1
	status = xTaskCreate(print_sem, "consumer", 200, (void*)semaphores, 2, NULL);
	if (status != pdPASS)
	{
		PRINTF("Task creation failed!.\r\n");
		while (1);
	}
	// task 3 - consumer 2
	status = xTaskCreate(PRINTCAP_sem, "consumer", 200, (void*)semaphores, 2, NULL);
	if (status != pdPASS)
	{
		PRINTF("Task creation failed!.\r\n");
		while (1);
	}

	vTaskStartScheduler();
	while (1)
	{}
}






